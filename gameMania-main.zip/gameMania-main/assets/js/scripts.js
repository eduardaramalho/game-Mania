const campos = document.querySelectorAll("[required]")

function validaCampo(campo) {
    function verificaErro() {
        let encontraErro = false;

        for(let erro in campo.validity) {
            if (campo.validity[erro] && !campo.validity.valid ) {
                encontraErro = erro
            }
        }
        return encontraErro;
    }

    function trocarMensagem(typeError) {
        const mensagem = {
            password: {
                valueMissing: "Senha é obrigatório",
                patternMismatch: `A senha deve conter entre 6 a 12 caracteres, deve conter pelo 
              menos uma letra maiúscula, um número e não deve conter símbolos.`
            },
            email: {
                valueMissing: "Email é obrigatório",
                typeMismatch: "Por favor, preencha um email válido"
            }
        }

        return mensagem[campo.type][typeError]
    }

    function setTrocarMensagem(mensagem) {
        const spanError = campo.parentNode.querySelector("span.error")
        
        if (mensagem) {
            spanError.classList.add("active")
            spanError.innerHTML = mensagem
        } else {
            spanError.classList.remove("active")
            spanError.innerHTML = ""
        }
    }

    return function() {

        const erro = verificaErro()

        if(erro) {
            const mensagem = trocarMensagem(erro)

            campo.style.borderColor = "red"
            setTrocarMensagem(mensagem)
        } else {
            campo.style.borderColor = "green"
            setTrocarMensagem()
        }
    }
}

function validacao (event) {

    const campo = event.target
    const validation = validaCampo(campo)

    validation()

}

for( campo of campos ){
    campo.addEventListener("invalid", event => { 
        event.preventDefault()

        validacao(event)
    })
    campo.addEventListener("blur", validacao)
}


document.querySelector("form").addEventListener("submit", event => {console.log("enviar o formulário")
    event.preventDefault()
})