const inputElement = document.querySelector(".new-item-input");
const addItem = document.querySelector(".new-item-button");

const puxaItemContainer = document.querySelector(".tasks-container");

const validaInput = () => inputElement.value.trim().length > 0;
//deixar vermelho se o input for inválido
const handleAddItem = () => {
    const inputValido = validaInput();
    console.log(inputValido);
    if(!inputValido){
        return inputElement.classList.add("error");
    }
 //criação da div 
    const itemContainer = document.createElement("div");
    itemContainer.classList.add("task-item");
 //criação do parágrafo
    const itemContent = document.createElement("p");
    itemContent.innerText=inputElement.value;

 //criação do icon
    const deleteItem = document.createElement('i');
    deleteItem.classList.add('fa-solid');
    deleteItem.classList.add('fa-trash-can');

    deleteItem.addEventListener('click', ( ) => handleDeleteClick(itemContainer, itemContent));

    itemContainer.appendChild(itemContent);
    itemContainer.appendChild(deleteItem);

    console.log({itemContainer});
//colocando o conteúdo da div dentro do puxaItemContainer e adicionando o item no box
    puxaItemContainer.appendChild(itemContainer );
//limpar o input ao adicionar um dado
    inputElement.value = " ";
    
};
//apagar um item
const handleDeleteClick = (itemContainer, itemContent ) =>{
    const itens = puxaItemContainer.childNodes;

    for(const item of itens){
        if (item.firstChild.isSameNode(itemContent)){
            itemContainer.remove();
        }
    }
}

//remover o vermelho se inserir campo no input
const handleInput = () => {
    const inputValido = validaInput();
    if(inputValido){
        return inputElement.classList.remove("error");
    }
};
//validação dos inputs
addItem.addEventListener("click",()=> handleAddItem());
inputElement.addEventListener('change', () => handleInput())
 

