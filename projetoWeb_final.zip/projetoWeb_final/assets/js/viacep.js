function limpaFormulario (){
    $("#rua").val("");
    $("#bairro").val("");
    $("#cidade").val("");
    $("#estado").val("");
}

$(document).ready( 
    function(){
        $("#botao").click(
            function(){
                let cep = $("#cep").val(); 
                $.getJSON("https://viacep.com.br/ws/"+ cep +"/json/?callback=?", 
                function(dados){ 
                    if(!("erro" in dados)) 
                    {
                        $("#rua").val(dados.logradouro);
                        $("#bairro").val(dados.bairro);
                        $("#cidade").val(dados.localidade);
                        $("#estado").val(dados.uf);
                    }
                    else {
                        limpaFormulario();
                        alert("cep inválido");
                     document.getElementById("error").innerHTML = "CEP inválido";
                    }
                })
        });
    } 
);
