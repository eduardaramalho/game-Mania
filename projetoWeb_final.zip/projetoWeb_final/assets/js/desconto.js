
  function calculaDesconto(){
    document.getElementById("valorTotal").value = '0';
     var precoSemDesconto = parseFloat(document.getElementById("valorInicial").value);
     var desconto = parseFloat(document.getElementById("desconto").value);
     var percentualDesconto = parseFloat((precoSemDesconto*desconto)/100);
     var precoFinal = parseFloat(precoSemDesconto)- parseFloat(percentualDesconto);
     document.getElementById("valorTotal").value = 'R$ ' + precoFinal.toFixed(2);
  
    }